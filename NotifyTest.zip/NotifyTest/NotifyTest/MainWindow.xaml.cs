﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Forms = System.Windows.Forms;

namespace NotifyTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Forms.NotifyIcon _notifyIcon;
        public MainWindow()
        {

            _notifyIcon = new Forms.NotifyIcon();
            _notifyIcon.Icon = new System.Drawing.Icon("Resources/mitsubishi.ico");
            _notifyIcon.Visible = true;
            _notifyIcon.MouseClick += _notifyIcon_MouseClick;

            _notifyIcon.ContextMenuStrip = new Forms.ContextMenuStrip();
            _notifyIcon.ContextMenuStrip.Items.Add("Click Here!!!", System.Drawing.Image.FromFile("Resources/mitsubishi.ico"), OnStatusClicked);

            _notifyIcon.BalloonTipClicked += _notifyIcon_BalloonTipClicked;
            _notifyIcon.BalloonTipClosed += _notifyIcon_BalloonTipClosed;

            var path = System.IO.Path.Combine(Environment.CurrentDirectory, "Resources", "mitsubishi.ico");
            var uri = new Uri(path);
            this.Icon = new BitmapImage(uri);
            Closed += _mainWindow_Closed;

            InitializeComponent();
        }

        private void _notifyIcon_BalloonTipClosed(object sender, EventArgs e)
        {
            _notifyIcon.ShowBalloonTip(5000, "These Tooltips...", "...cannot be closed.", Forms.ToolTipIcon.Info);
        }

        private void _notifyIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            this.WindowState = WindowState.Normal;
            this.Activate();
        }

        private void _notifyIcon_MouseClick(object sender, Forms.MouseEventArgs e)
        {
            if (e.Button != Forms.MouseButtons.Left)
                return;
            this.WindowState = WindowState.Normal;
            this.Activate();
        }

        private void OnStatusClicked(object sender, EventArgs e)
        {
            _notifyIcon.ShowBalloonTip(5000, "AAAAAAAHHHH!!!", "SOMEONE CLICKED ON IT!!!!", Forms.ToolTipIcon.Info);
        }


        private void _mainWindow_Closed(object sender, EventArgs e)
        {
            _notifyIcon.Dispose();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _notifyIcon.ShowBalloonTip(5000, "IMPORTANT!!!!", "THIS IS EXTREMELY IMPORTANT!!!", Forms.ToolTipIcon.Info);
        }
    }
}
